

abstract class User {

  bool isStoreOwner;

  void login();
  void logout();
}